<?php
/** @package    Forum::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * ConteudoCriteria allows custom querying for the Conteudo object.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * Add any custom business logic to the ModelCriteria class which is extended from this class.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @inheritdocs
 * @package Forum::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class ConteudoCriteriaDAO extends Criteria
{

	public $Id_Equals;
	public $Id_NotEquals;
	public $Id_IsLike;
	public $Id_IsNotLike;
	public $Id_BeginsWith;
	public $Id_EndsWith;
	public $Id_GreaterThan;
	public $Id_GreaterThanOrEqual;
	public $Id_LessThan;
	public $Id_LessThanOrEqual;
	public $Id_In;
	public $Id_IsNotEmpty;
	public $Id_IsEmpty;
	public $Id_BitwiseOr;
	public $Id_BitwiseAnd;
	public $Nome_Equals;
	public $Nome_NotEquals;
	public $Nome_IsLike;
	public $Nome_IsNotLike;
	public $Nome_BeginsWith;
	public $Nome_EndsWith;
	public $Nome_GreaterThan;
	public $Nome_GreaterThanOrEqual;
	public $Nome_LessThan;
	public $Nome_LessThanOrEqual;
	public $Nome_In;
	public $Nome_IsNotEmpty;
	public $Nome_IsEmpty;
	public $Nome_BitwiseOr;
	public $Nome_BitwiseAnd;
	public $Descricao_Equals;
	public $Descricao_NotEquals;
	public $Descricao_IsLike;
	public $Descricao_IsNotLike;
	public $Descricao_BeginsWith;
	public $Descricao_EndsWith;
	public $Descricao_GreaterThan;
	public $Descricao_GreaterThanOrEqual;
	public $Descricao_LessThan;
	public $Descricao_LessThanOrEqual;
	public $Descricao_In;
	public $Descricao_IsNotEmpty;
	public $Descricao_IsEmpty;
	public $Descricao_BitwiseOr;
	public $Descricao_BitwiseAnd;
	public $Link_Equals;
	public $Link_NotEquals;
	public $Link_IsLike;
	public $Link_IsNotLike;
	public $Link_BeginsWith;
	public $Link_EndsWith;
	public $Link_GreaterThan;
	public $Link_GreaterThanOrEqual;
	public $Link_LessThan;
	public $Link_LessThanOrEqual;
	public $Link_In;
	public $Link_IsNotEmpty;
	public $Link_IsEmpty;
	public $Link_BitwiseOr;
	public $Link_BitwiseAnd;
	public $User_Equals;
	public $User_NotEquals;
	public $User_IsLike;
	public $User_IsNotLike;
	public $User_BeginsWith;
	public $User_EndsWith;
	public $User_GreaterThan;
	public $User_GreaterThanOrEqual;
	public $User_LessThan;
	public $User_LessThanOrEqual;
	public $User_In;
	public $User_IsNotEmpty;
	public $User_IsEmpty;
	public $User_BitwiseOr;
	public $User_BitwiseAnd;
	public $Admin_Equals;
	public $Admin_NotEquals;
	public $Admin_IsLike;
	public $Admin_IsNotLike;
	public $Admin_BeginsWith;
	public $Admin_EndsWith;
	public $Admin_GreaterThan;
	public $Admin_GreaterThanOrEqual;
	public $Admin_LessThan;
	public $Admin_LessThanOrEqual;
	public $Admin_In;
	public $Admin_IsNotEmpty;
	public $Admin_IsEmpty;
	public $Admin_BitwiseOr;
	public $Admin_BitwiseAnd;
	public $CreatedAt_Equals;
	public $CreatedAt_NotEquals;
	public $CreatedAt_IsLike;
	public $CreatedAt_IsNotLike;
	public $CreatedAt_BeginsWith;
	public $CreatedAt_EndsWith;
	public $CreatedAt_GreaterThan;
	public $CreatedAt_GreaterThanOrEqual;
	public $CreatedAt_LessThan;
	public $CreatedAt_LessThanOrEqual;
	public $CreatedAt_In;
	public $CreatedAt_IsNotEmpty;
	public $CreatedAt_IsEmpty;
	public $CreatedAt_BitwiseOr;
	public $CreatedAt_BitwiseAnd;
	public $UpdatedAt_Equals;
	public $UpdatedAt_NotEquals;
	public $UpdatedAt_IsLike;
	public $UpdatedAt_IsNotLike;
	public $UpdatedAt_BeginsWith;
	public $UpdatedAt_EndsWith;
	public $UpdatedAt_GreaterThan;
	public $UpdatedAt_GreaterThanOrEqual;
	public $UpdatedAt_LessThan;
	public $UpdatedAt_LessThanOrEqual;
	public $UpdatedAt_In;
	public $UpdatedAt_IsNotEmpty;
	public $UpdatedAt_IsEmpty;
	public $UpdatedAt_BitwiseOr;
	public $UpdatedAt_BitwiseAnd;

}

?>