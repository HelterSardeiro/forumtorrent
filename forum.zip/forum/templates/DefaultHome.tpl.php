<?php
	$this->assign('title','FORUM | Home');
	$this->assign('nav','home');

	$this->display('_Header.tpl.php');
?>

	<h1 style="color: red">FORUM MANUTENÇÃO DATABASE </h1>

<?php
	$this->display('_Footer.tpl.php');
?>