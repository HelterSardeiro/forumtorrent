<?php
/** @package    Forum::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * ComentarioCriteria allows custom querying for the Comentario object.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * Add any custom business logic to the ModelCriteria class which is extended from this class.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @inheritdocs
 * @package Forum::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class ComentarioCriteriaDAO extends Criteria
{

	public $Id_Equals;
	public $Id_NotEquals;
	public $Id_IsLike;
	public $Id_IsNotLike;
	public $Id_BeginsWith;
	public $Id_EndsWith;
	public $Id_GreaterThan;
	public $Id_GreaterThanOrEqual;
	public $Id_LessThan;
	public $Id_LessThanOrEqual;
	public $Id_In;
	public $Id_IsNotEmpty;
	public $Id_IsEmpty;
	public $Id_BitwiseOr;
	public $Id_BitwiseAnd;
	public $Texto_Equals;
	public $Texto_NotEquals;
	public $Texto_IsLike;
	public $Texto_IsNotLike;
	public $Texto_BeginsWith;
	public $Texto_EndsWith;
	public $Texto_GreaterThan;
	public $Texto_GreaterThanOrEqual;
	public $Texto_LessThan;
	public $Texto_LessThanOrEqual;
	public $Texto_In;
	public $Texto_IsNotEmpty;
	public $Texto_IsEmpty;
	public $Texto_BitwiseOr;
	public $Texto_BitwiseAnd;
	public $ConteudoId_Equals;
	public $ConteudoId_NotEquals;
	public $ConteudoId_IsLike;
	public $ConteudoId_IsNotLike;
	public $ConteudoId_BeginsWith;
	public $ConteudoId_EndsWith;
	public $ConteudoId_GreaterThan;
	public $ConteudoId_GreaterThanOrEqual;
	public $ConteudoId_LessThan;
	public $ConteudoId_LessThanOrEqual;
	public $ConteudoId_In;
	public $ConteudoId_IsNotEmpty;
	public $ConteudoId_IsEmpty;
	public $ConteudoId_BitwiseOr;
	public $ConteudoId_BitwiseAnd;
	public $CreatedAt_Equals;
	public $CreatedAt_NotEquals;
	public $CreatedAt_IsLike;
	public $CreatedAt_IsNotLike;
	public $CreatedAt_BeginsWith;
	public $CreatedAt_EndsWith;
	public $CreatedAt_GreaterThan;
	public $CreatedAt_GreaterThanOrEqual;
	public $CreatedAt_LessThan;
	public $CreatedAt_LessThanOrEqual;
	public $CreatedAt_In;
	public $CreatedAt_IsNotEmpty;
	public $CreatedAt_IsEmpty;
	public $CreatedAt_BitwiseOr;
	public $CreatedAt_BitwiseAnd;
	public $UpdatedAt_Equals;
	public $UpdatedAt_NotEquals;
	public $UpdatedAt_IsLike;
	public $UpdatedAt_IsNotLike;
	public $UpdatedAt_BeginsWith;
	public $UpdatedAt_EndsWith;
	public $UpdatedAt_GreaterThan;
	public $UpdatedAt_GreaterThanOrEqual;
	public $UpdatedAt_LessThan;
	public $UpdatedAt_LessThanOrEqual;
	public $UpdatedAt_In;
	public $UpdatedAt_IsNotEmpty;
	public $UpdatedAt_IsEmpty;
	public $UpdatedAt_BitwiseOr;
	public $UpdatedAt_BitwiseAnd;

}

?>