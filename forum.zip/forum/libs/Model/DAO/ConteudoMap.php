<?php
/** @package    Forum::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/IDaoMap.php");
require_once("verysimple/Phreeze/IDaoMap2.php");

/**
 * ConteudoMap is a static class with functions used to get FieldMap and KeyMap information that
 * is used by Phreeze to map the ConteudoDAO to the conteudo datastore.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * You can override the default fetching strategies for KeyMaps in _config.php.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @package Forum::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class ConteudoMap implements IDaoMap, IDaoMap2
{

	private static $KM;
	private static $FM;
	
	/**
	 * {@inheritdoc}
	 */
	public static function AddMap($property,FieldMap $map)
	{
		self::GetFieldMaps();
		self::$FM[$property] = $map;
	}
	
	/**
	 * {@inheritdoc}
	 */
	public static function SetFetchingStrategy($property,$loadType)
	{
		self::GetKeyMaps();
		self::$KM[$property]->LoadType = $loadType;
	}

	/**
	 * {@inheritdoc}
	 */
	public static function GetFieldMaps()
	{
		if (self::$FM == null)
		{
			self::$FM = Array();
			self::$FM["Id"] = new FieldMap("Id","conteudo","id",true,FM_TYPE_INT,11,null,true);
			self::$FM["Nome"] = new FieldMap("Nome","conteudo","nome",false,FM_TYPE_VARCHAR,100,null,false);
			self::$FM["Descricao"] = new FieldMap("Descricao","conteudo","descricao",false,FM_TYPE_TEXT,null,null,false);
			self::$FM["Link"] = new FieldMap("Link","conteudo","link",false,FM_TYPE_TEXT,null,null,false);
			self::$FM["User"] = new FieldMap("User","conteudo","user",false,FM_TYPE_INT,11,null,false);
			self::$FM["Admin"] = new FieldMap("Admin","conteudo","admin",false,FM_TYPE_INT,11,null,false);
			self::$FM["CreatedAt"] = new FieldMap("CreatedAt","conteudo","created_at",false,FM_TYPE_TIMESTAMP,null,"CURRENT_TIMESTAMP",false);
			self::$FM["UpdatedAt"] = new FieldMap("UpdatedAt","conteudo","updated_at",false,FM_TYPE_TIMESTAMP,null,"0000-00-00 00:00:00",false);
		}
		return self::$FM;
	}

	/**
	 * {@inheritdoc}
	 */
	public static function GetKeyMaps()
	{
		if (self::$KM == null)
		{
			self::$KM = Array();
			self::$KM["comentario_ibfk_1"] = new KeyMap("comentario_ibfk_1", "Id", "Comentario", "ConteudoId", KM_TYPE_ONETOMANY, KM_LOAD_LAZY);  // use KM_LOAD_EAGER with caution here (one-to-one relationships only)
			self::$KM["conteudo_ibfk_1"] = new KeyMap("conteudo_ibfk_1", "User", "Users", "Id", KM_TYPE_MANYTOONE, KM_LOAD_LAZY); // you change to KM_LOAD_EAGER here or (preferrably) make the change in _config.php
			self::$KM["conteudo_ibfk_2"] = new KeyMap("conteudo_ibfk_2", "Admin", "Admins", "Id", KM_TYPE_MANYTOONE, KM_LOAD_LAZY); // you change to KM_LOAD_EAGER here or (preferrably) make the change in _config.php
		}
		return self::$KM;
	}

}

?>