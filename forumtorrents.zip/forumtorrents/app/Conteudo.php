<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Conteudo extends Model
{
    protected $fillable = ['nome', 'descricao', 'link', 'user', 'admin'];
    protected $guarded = ['idconteudo', 'created_at',  'update_at'];
    protected $table = 'conteudo';
    public static function busca($nome)
    {
      return static::where('nome', 'LIKE', '%' . $nome . '%')->get();
    }
}


