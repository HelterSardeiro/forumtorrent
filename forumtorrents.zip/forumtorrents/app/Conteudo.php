<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Conteudo extends Model
{
    protected $fillable = ['nome', 'descricao', 'link', 'usuario_idusuario', 'admin_idadmin'];
    protected $guarded = ['idconteudo', 'created_at',  'update_at'];
    protected $table = 'conteudo';
}
