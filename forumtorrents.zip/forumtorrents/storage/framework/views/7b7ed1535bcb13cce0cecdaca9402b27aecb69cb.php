 

        <?php $__env->startSection('content'); ?>
        <?php if(session('message')): ?>
        <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" 
               data-dismiss="alert"
               aria-label="close">&times;</a>
            <?php echo e(session('message')); ?>


            <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
        </div>
        <?php endif; ?>
        <div id="line-one">   
            <div class="container">
                <div class="row">
                    <div class="col-md-12" id="center"> 
                        <h1><b>Conteudos</b></h1>
                        <br>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <a href="<?php echo e(route('conteudo.create')); ?>" 
                           class="btn btn-default btn-sm pull-right">
                            <span class="glyphicon glyphicon-plus"></span> Adicionar</a>
                        <div id="pesquisa" class="pull-right">
                            <form class="form-group" method="post" 
                                  action="<?php echo e(url('/busca')); ?>">   
                                  <?php echo e(csrf_field()); ?>                                
                                <input type="text" name="nome" 
                                       class="form-control input-sm pull-left" 
                                       placeholder="Pesquisar na pagina principal..." required> 
                                <button class="btn btn-default btn-sm pull-right" 
                                        id="color"> 
                                    <span class="glyphicon glyphicon-search"></span>
                                </button>
                            </form>
                        </div>
                    </div>           
                </div>
                <div class="row">
                    <div class="col-md-12">   
                        <br />
                        <h4 id="center"><b>CONTEUDOS CADASTRADOS (<?php echo e($total); ?>)</b></h4>
                        <br>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th id="center">Código</th>
                                        <th>Nome</th>
                                        <th>Descrição</th>
                                        <th id="center">Link</th>
                                        <th id="center">Ações</th>              
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $conteudos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conteudo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                    if(Auth::user()->id == $conteudo->user){

                                    
                                    ?>
                                    <tr>
                                        <td id="center"><?php echo e($conteudo->id); ?></td>
                                        <td title="Nome"><?php echo e($conteudo->nome); ?></td>
                                        <td title="Descrição"><?php echo e($conteudo->descricao); ?></td>
                                        <td title="Quantidade" id="center"><?php echo e($conteudo->link); ?></td>
                            
                                         <td id="center">
                                            <a class='btn btn-info' href="<?php echo e(route('conteudo.edit', $conteudo->id)); ?>" 
                                               data-toggle="tooltip" 
                                               data-placement="top"
                                               title="Alterar">Editar</a>
                                            &nbsp;<form style="display: inline-block;" method="POST" 
                                                        action="<?php echo e(route('conteudo.destroy', $conteudo->id)); ?>"                                                        
                                                        data-toggle="tooltip" data-placement="top"
                                                        title="Excluir" 
                                                        onsubmit="return confirm('Confirma exclusão?')">
                                                <?php echo e(method_field('DELETE')); ?><?php echo e(csrf_field()); ?>                                                
                                                <button class='btn btn-danger' type="submit">
                                                    Excluir                                                    
                                                </button></form></td>              
                                    </tr>
                                    <?php }?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <img src="<?php echo e(URL::asset('img/subir.png')); ?>" 
                 id="up" 
                 style="display: none;" 
                 alt="Ícone Subir ao Topo" 
                 title="Subir ao topo?">
         <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>